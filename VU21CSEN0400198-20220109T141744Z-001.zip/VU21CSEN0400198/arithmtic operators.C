#include<stdio.h>
int main()
{
int a,b,c,d,sum=0;
printf("enter the a,b value");
scanf("%f,6+a/5*b\n");
printf("enter the a,b value");
scanf("%f,a/b*b\n");
printf("enter the c,d value");
scanf("%f,c/d*d\n");
printf("enter the a value");
scanf("%f,-a\n");
}
