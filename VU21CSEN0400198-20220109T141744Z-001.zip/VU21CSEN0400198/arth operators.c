#include<stdio.h>
 main()
 {
 	int a=25,b=2,c=25.0,d=2.0;
 	printf("%d\n",6+a/5*b);
 	printf("%d\n",a/b*b);
 	printf("%d\n",c/d*d);
 	printf("%d\n",-a);
 }
