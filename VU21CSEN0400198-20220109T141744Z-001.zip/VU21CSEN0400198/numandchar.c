#include<stdio.h>
main()
{
	char c;
    printf("enter the character\n");
    scanf("%c",&c);
    switch(c>=65&&c>=97)
    {
    	case 1:
    		printf("it is a character\n");
    		break;
    	case 0:
    		switch(c>=0&&c<=9)
    		printf("the character is a digit\n");
    		break;
    		
    
   	}
}
