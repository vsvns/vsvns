#include<stdio.h>
main()
{
	float radius,area,perimeter,volume;
	printf("enter the value of radius\n");
	scanf("%f",&radius);
	perimeter=2*3.14*radius;
	printf("perimeter of the circle %f\n",perimeter);
	area=3.14*radius*radius;
	printf("area of the circle %f\n",area);
	volume=1.33*3.24*radius*radius;
	printf("volume of a circle %f\n",volume);
	
}
