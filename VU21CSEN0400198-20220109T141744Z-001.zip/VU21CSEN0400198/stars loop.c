#include<stdio.h>
main()
{
	int a=1,n;
	printf("enter the n value\n");
	scanf("%d",&n);
	do 
	{
		printf("*",a);
		a=(a+1);
	}
	while(a<=n);
	
}
