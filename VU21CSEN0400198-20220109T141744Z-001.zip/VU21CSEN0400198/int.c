#include<stdio.h>
main()
{
	int a;
	printf("enter the a value \n");
	scanf("%d",&a);
	if (a==0)
	{
	printf("a is equal to zero \n");
	}
	else if(a<0)
	{
	printf("a is negative \n");
	}
	else if(a>0)
	{
	printf("a is positive \n");
    }
}
