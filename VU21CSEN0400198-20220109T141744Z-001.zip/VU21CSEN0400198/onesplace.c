#include<stdio.h>
main()
{
	float a;
	printf("enter the value of a \n");
	scanf("%f",&a);
    printf("%f\n,%10",%10);
}
