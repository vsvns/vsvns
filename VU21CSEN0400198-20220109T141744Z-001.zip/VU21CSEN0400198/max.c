#include<stdio.h>
main()
{
	int a,b,c;
	printf("enter the a value \n");
	scanf("%d",&a);
	printf("enter the b value");
	scanf("%d",&b);
	printf("enter the c value");
	scanf("%d",&c);
	if("a<b||b<c")
	
}
