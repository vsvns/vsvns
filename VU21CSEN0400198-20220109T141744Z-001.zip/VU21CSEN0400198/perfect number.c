#include<stdio.h>
main()
{
	int i=1,n,sum=0;
	printf("enter the n value\n");
	scanf("%d",&n);
	while(i<n)
	{
		if(n%i==0)
	sum=sum+i;
	i++;
	}
	if(sum==n)
	printf("it is a perfect number %d\n",n);
	else 
	printf("not a perfect number %d\n",n);
}
