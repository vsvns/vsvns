#include<stdio.h>
main()
{
	int i=1,n,fact=1;
	printf("enter the n value\n");
	scanf("%d",&n);
	while(i<=n)
	{
	fact=fact*i;
	printf("%d\n",fact);
	i++;	
	}
}
