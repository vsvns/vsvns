#include<stdio.h>
main()
{
	float coin1=10.0,coin2=20.0,coin3=50.0,coin4=100.0,coin5=500.0,total,ncoin1,ncoin2,ncoin3,ncoin4,ncoin5;
	printf("no of ncoin1\n");
	scanf("%f",&ncoin1);
	total=(ncoin1*coin1);
	printf("the total %f\n",total);
	fflush(stdin);
	printf("no of ncoin2 \n");
	scanf("%f",&ncoin2);
	total=(ncoin2*coin2);
	printf("the total %f\n",total);
	fflush(stdin);
	printf("no of ncoin3 \n");
	scanf("%f",&ncoin3);
	total=(ncoin3*coin3);
	printf("the total %f\n",total);
	fflush(stdin);
	printf("no of ncoin4\n");
	scanf("%f",&ncoin4);
	total=(ncoin4*coin4);
	printf("the total%f\n",total);
	fflush(stdin);
	printf("no of ncoin5 \n");
	scanf("%f",&ncoin5);
	total=(ncoin5*coin5);
	printf("the total %f\n",total);
}
