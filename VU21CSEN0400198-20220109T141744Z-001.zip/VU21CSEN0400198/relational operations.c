#include<stdio.h>
main()
{
	int a=5,b=6;
	printf("a==b value is %d\n",a==b);
}
