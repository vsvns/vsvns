#include<stdio.h>
main()
{
	int i,count=0,n;
	printf("enter the value of n\n");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		if(n%i==0)
	    count++;
	}
	if(count==2)
	printf("%d is a prime number");
	else
	printf("%d not prime");
}
