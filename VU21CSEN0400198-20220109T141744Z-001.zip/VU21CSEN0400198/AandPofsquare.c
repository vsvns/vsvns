#include<stdio.h>
main()
{
	float side,area,perimeter;
	printf("enter the value of a side \n");
	scanf("%f",&side);
	perimeter=4*side;
	printf("perimeter of a square %f\n",perimeter);
    area=side*side;
	printf("area of the square %f\n",area);
}
