#include<stdio.h>
main()
{
	char c;
	printf("enter the character\n");
	scanf("%c",&c);
	switch(c)
	{
		case 'A'...'Z':
			(c=c+32);
			printf("converted character %c\n",c);
			break;
		case'a'...'z':
			(c=c-32);
			printf("converted character %c\n",c);
			break;
		case'0'...'9':
			printf("it is a digit %d\n",c);
			
	}
	
}
