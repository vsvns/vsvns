#include<stdio.h>
main()
{
	int a,b;
	printf("enter the a value \n");
	scanf("%d",&a);
	printf("enter the b value \n");
	scanf("%d",&b);
	if(a>b)
	{ 
	printf("a is maximum");
    }
    else if(a<b)
    {
    printf("a is minimum");
	}
}


