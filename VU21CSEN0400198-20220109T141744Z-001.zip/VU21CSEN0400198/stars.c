#include<stdio.h>
main()
{
	int i=1,n;
	printf("enter the number of times the statements\n");
	scanf("%d",&n);
	while(i<=n)
	{
		printf("*");
		i++;
	}
}
