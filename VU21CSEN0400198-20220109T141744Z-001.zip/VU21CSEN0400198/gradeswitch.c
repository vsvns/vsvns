#include<stdio.h>
main()
{
	int a,A,B,C,D,E,F;
	printf("enter the a value\n");
	scanf("%d",&a);
	switch(a>=90)
	{
		case'a>90':
			printf("A grade %d\n",A);
			break;
			}
		{
		case 2:
		    switch (a>=80)
			printf("B grade %d\n",B);
		    break;
		}
		{
		case 3:
		    switch(a>=70)
			printf("C grade %d\n",C);
			break;
		}
		{
	    case 4:
			 switch(a>=60)
			printf("D grade %d\n",D);
			break;
			}
			
		{
	    case 5:
			 switch(a>=50)
			printf("E grade %d\n",E);
		    break;
		   }  
		{
		case 6:
			 switch(a<50)
			printf("F grade %d\n",F);
			break;
		}
			}
	}
}
