#include<stdio.h>
main()
{
	int a,k;
	printf("enter the a value\n");
	scanf("%d",&a);
	k=a%2;
	switch(k)
	{
		case 0:
			printf("even number\n");
			break;
		case 1:
		    printf("odd number\n");
		    break;
		default:
			printf("other than odd and even\n");		    
	}
}
	
