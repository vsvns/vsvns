#include<stdio.h>
main()
{
	int n,i=1;
	printf("enter the n value\n");
	scanf("%d",&n);
	while(i<=n/2)
	{
		if(n%1==0)
		++i;
	}
	{
	if(n==1)
	printf("it is not a prime number\n",n);
    else 
	printf("it is a prime number\n",n);
}
}
