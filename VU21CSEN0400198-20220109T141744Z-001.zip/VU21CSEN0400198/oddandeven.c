#include<stdio.h>
main()
{
	int a;
	printf("enter the a value \n");
	scanf("%d",&a);
	if (a%2==0)
	{
	printf("a is even \n");
	}
	else if (a%2!=0)
	{
	printf("a is odd \n");
	}
}
