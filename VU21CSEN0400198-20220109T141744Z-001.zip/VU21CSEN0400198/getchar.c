#include<stdio.h>
int main()
{
	char c;
	printf("enter some character \n");
	c=getchar();
	printf("entered character is \n");
	putchar(c);
	printf("\n");
	
}
