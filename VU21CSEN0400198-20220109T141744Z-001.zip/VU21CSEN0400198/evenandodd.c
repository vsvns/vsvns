#include<stdio.h>
main()
{
	int i=1,n,sum=0;
	printf("enter the n value\n");
	scanf("%d",&n);
	while(i<=n)
	{
	if(n%i==0)
	sum=(sum+2);
	i++;
	printf("it is an even number %d\n",sum);
   }
	printf("it is an odd number %d\n",sum);
   }
  }
