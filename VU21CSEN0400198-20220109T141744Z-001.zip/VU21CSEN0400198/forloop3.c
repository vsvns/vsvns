#include<stdio.h>
main()
{
	int i,n;
	printf("enter the n value\n");
	scanf("%d",&n);
	for(i=1;n-i;i<=5)
	{
	printf("%d\t\n",i);
	}
}
