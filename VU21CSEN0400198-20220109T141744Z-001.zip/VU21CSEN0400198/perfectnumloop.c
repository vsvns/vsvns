#include<stdio.h>
main()
{
	int i=1,n,sum=0;
	printf("enter the n value\n");
	scanf("%d",&n);
	do
	{
		if(n%i==0)
		sum=sum+i;
		i++;	
	}
	 while(i<n);
	 if(sum==n)
	 printf("%d is a perfect number\n",n);
	 else
	 printf("%d is not a perfect number\n",n);
}
