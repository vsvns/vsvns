#include<stdio.h>
main()
{
	float a,b,c,mul;
	printf("enter the a value");
	scanf("%f",&a);
	printf("enter the b value");
	scanf("%f",&b);
	c=a*b;
	printf("mul of two numbers %f\n",c);
}
