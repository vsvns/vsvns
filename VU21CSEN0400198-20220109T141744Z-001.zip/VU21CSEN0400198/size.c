#include<stdio.h>
main()
{
	printf("sizeof an integer %d",sizeof(double));
}
