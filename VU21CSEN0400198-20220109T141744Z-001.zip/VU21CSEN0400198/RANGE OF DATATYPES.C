#include<limits.h>
main()
{ 
   printf("range of max int is %d",INT_MAX);
   printf("range of min int is %d",INT_MIN);
}
