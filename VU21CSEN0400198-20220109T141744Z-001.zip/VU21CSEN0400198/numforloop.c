#include<stdio.h>
main()
{
	int i,j,k;
	for(i=1;i<2;i++)
	{
	 for(j=2;j<3;j++,i)
	{
	for(k=3;k<4;k++,i,j)
	{
	printf("%d\n%d\t\n%d\t\n",i,j,k);
	}
    }
    }
}
