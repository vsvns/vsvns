#include<stdio.h>
main()
{
	char c;
	printf("entered character is\n");
	scanf("%c",&c);
	switch(c>=65&&c>=97)
	{
		case 1:
		  (c=c-32);
		  printf("converted character is %c",c);
		  break;
		case 0:
		  (c=c+32);
		  printf("converted character is %c",c);
		  break;	    
	}
}
