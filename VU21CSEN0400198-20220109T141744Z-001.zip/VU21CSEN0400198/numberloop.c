#include<stdio.h>
main()
{
	int i=1,n;
	printf("enter the number\n");
	scanf("%d",&n);
	while(n>=i)
	{
		printf("%d\n",n);
		n--;
	}
}
