#include<stdio.h>
main()
{
float side,area;
printf("enter length of side of square/n");
scanf ("%f",&side);
area=side*side;
printf("area of square,area");
}
