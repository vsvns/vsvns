#include<stdio.h>
main()
{
	char c;
	printf("enter some character \n");
	c=getchar();
c++;
	
	putchar(c);
	printf("\n");
	fflush(stdin);
	c=getchar();
c++;
	putchar(c);
	fflush(stdin);
	c=getchar();
c
	putchar(c);
	
}
