#include<stdio.h>
int main()
{
	int a=25,b=2,c=25.0,d=2.0;
	printf("%d,6+a/5*b\n");
	printf("%d,a/b*b\n");
	printf("%d,c/d*d\n");
	printf("%d,-a\n");
}
