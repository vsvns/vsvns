#include<stdio.h>
main()
{
	int i=1,n,k;
	printf("enter the n value\n");
	scanf("%d",&n);
	while(i<=n)
	{
		(i%2==0);
		i++;
		printf("%d\n",i);
	}
	
	
	
}
