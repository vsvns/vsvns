#include<stdio.h>
main()
{
	int a,b,c;
	printf("enter the a value\n");
	scanf("%d",&a);
	printf("enter the b value\n");
	scanf("%d",&b);
	printf("enter the c value\n");
	scanf("%d",&c);
	if(a==c && a==b && b==c)
	printf("it is and equilateral triangle");
	else if(a==b && a!=c)
	printf("it is an isosceles triangle");
	else if(a!=b && a!=c && b!=c)
	printf("it is an scalent triangle");
}
