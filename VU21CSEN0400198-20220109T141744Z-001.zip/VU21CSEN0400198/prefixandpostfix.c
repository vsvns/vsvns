#include<stdio.h>
int main()
{
	int a,b;
	printf("enter the value of a \n");
	scanf("%d",&a);
	printf("%d\n",a++);
	printf("enter the value of b");
	scanf("%d",&b);
	printf("%d\n",++b);
	
}
