#include<stdio.h>
main()
{
	int s,area,perimeter;
	printf("enter the value");
	scanf("%d",&s);
	area=s*s;
	perimeter=4*s;
	printf("%d %d",area,perimeter);
}
