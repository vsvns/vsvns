#include<stdio.h>
main()
{
	int a=2;
	printf("complement is %d",~2);
}
