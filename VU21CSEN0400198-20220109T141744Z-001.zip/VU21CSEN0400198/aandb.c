#include<stdio.h>
main()
{
	int a,b;
	printf("enter th a value \n");
	scanf("%d",&a);
	printf("enter the b value \n");
	scanf("%d",&b);
	if(a==b)
	{
	printf("a and b are equal \n");
	}
	else if(a!=b)
	{
	printf("a and b are not equal \n");
	}
	
}
