#include<stdio.h>
main()
{
	int sum=0,n,k;
	printf("enter the n value\n");
	scanf("%d",&n);
	while(n>0)
	{
		k=(n%10);
		sum=(sum+k);
		n=(n/10);
		printf("%d\n",n);		
	}
}
