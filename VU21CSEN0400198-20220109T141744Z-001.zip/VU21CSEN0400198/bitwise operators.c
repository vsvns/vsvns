#include<stdio.h>
main()
{
	int a=5,b=6;
	printf("bitwise and operator for 5,6 is %d\n",5&6);
}
