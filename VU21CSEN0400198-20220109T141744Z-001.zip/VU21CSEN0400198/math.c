#include<math.h>
main()
{
	float x1=10,x2=5,y1=7,y2=5;
	printf("%f\n",sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)));
}
