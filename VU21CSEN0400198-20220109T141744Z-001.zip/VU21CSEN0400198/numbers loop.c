#include<stdio.h>
main()
{
	int a=10;
	do
	{
		printf("a is %d\n",a);
		a=a+1;
	}
	while(a<=30);

}
