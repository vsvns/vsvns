#include<stdio.h>
void main()
{
	int a,b,c;
	scanf("%d%d%d",&a,&b,&c);
	printf("a=%d,b=%d,c=%d",a,b,c);
}
