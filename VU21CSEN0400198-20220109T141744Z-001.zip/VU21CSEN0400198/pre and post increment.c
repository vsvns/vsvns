#include<stdio.h>
main()
{
int i=42;
printf("i value is %d\n",++i);
i=42;
printf("i value is %d\n",i++);
i=42;
printf("i value is %d\n",--i);
i=42;
printf("i value is %d\n",i--);
}
