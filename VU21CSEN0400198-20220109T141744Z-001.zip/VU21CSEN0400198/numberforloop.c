#include<stdio.h>
main()
{
	int i;
	for(i=0;i<1;i++)
	{
		printf("*\n");
		printf("**\n");
		printf("***\n");
	}
}
