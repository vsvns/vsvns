#include<stdio.h>
main()
{
	int i=0,n,sum=0;
	printf("enter the n value\n");
	scanf("%d",&n);
	do
	{
		sum=sum+i;
		printf("sum is %d\n",sum);
		i++;
	}
	while(i<=n);
}
