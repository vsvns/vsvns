#include<stdio.h>
main()
{
	int a=5,b=6;
	printf("5 is not greater than 6 %d\n",5<6)?:printf("5 is greater than 6 %d\n",5>6);
	
}
	



