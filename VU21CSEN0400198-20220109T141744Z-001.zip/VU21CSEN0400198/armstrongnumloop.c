#include<stdio.h>
main()
{
	int d,n,sum=0,k;
	printf("enter the n value\n");
	scanf("%d",&n);
	n=k;
	do
	{
	printf("%d\n",sum);
	 d=(n%10);
	 sum=(d*d*d+sum);
	 n=(n/10);
	}
	while(n<0);
	if(sum==k)
	printf(" %d is an armstrong number\n",k);
	else if(sum!=k)
	printf("%d is not an armstrong number\n",k);
}
