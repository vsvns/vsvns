#include<stdio.h>
main()
{
	int i;
	{
	for(i=1;i<=5;i++)
	{
		printf("%d\n",i);
    }
	}
}
