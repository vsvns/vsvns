#include<stdio.h>
main()
{
	int r=0,n,d;
	printf("enter the n value\n");
	scanf("%d",&n);
	do
	{
		
		d=(n%10);
		r=(r*10+d);
		n=(n/10);
		printf("reverse number %d\n",r);
	}
	while(n>0);
		
}
