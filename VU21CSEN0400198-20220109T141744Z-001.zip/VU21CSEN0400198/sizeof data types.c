#include<stdio.h>
main()
{
   printf("sizeof integer %d",sizeof(unsigned long int));
    printf("sizeof integer %d",sizeof(unsigned long int));
}
