#include<stdio.h>
main()
{
	float base,height,area;
	printf("enter the value of base \n");
	scanf("%f",&base);
	printf("enter the value of height \n");
	scanf("%f",&height);
	area=0.5*base*height;
	printf("area of a triangle %f\n",area);
	
	
}
	

