#include<stdio.h>
main()
{
	float a,b,c,div;
	printf("enter the a value");
	scanf("%f",&a);
	printf("enter the b value");
	scanf("%f",&b);
	c=a/b;
	printf("div of 2 numbers %f\n",c);
}
