#include<stdio.h>
main()
{
	char c;
	printf("enter the character \n");
	c=getchar();
	printf("%c\n",c++);
	printf("%c\n",c++);
	printf("entered character is \n");
	putchar(c);
	printf("\n");
	
}
