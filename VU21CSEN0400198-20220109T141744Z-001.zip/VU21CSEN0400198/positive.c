#include<stdio.h>
main()
{
	int a;
	printf("enter the a value\n");
	scanf("%d",&a);
	switch(a>0)
{
		case 1:
		  printf("POSITIVE");
		  break;
		case 0:
		  printf("NEGATIVE");
		  break;
		default:
			printf("ZERO");
		break;
	}
		
}
