#include<stdio.h>
main()
{
	int i=1,n,a,s,avg;
	printf("enter the number\n");
	scanf("%d",&n);
	while(n>=i)
	{
		scanf("%d\n",&a);
		s=s+a;
		i++;	
	}
	printf("sum is %d\n",s);
	avg=(float)(s/n);
	printf("average is %d\n",avg);
}
