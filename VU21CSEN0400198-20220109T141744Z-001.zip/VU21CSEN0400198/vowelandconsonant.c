#include<stdio.h>
main()
{
	char c,a,e,i,u,o;
	print("enter some character %c \n",c);
	scanf("%c",&c);
    c=getchar();
    printf("entered character is \n");
    putchar(c);
    if(c==a,e,i,o,u)
    printf("c is a vowel %c\n",c);
    else if(c!=a,e,i,o,u)
    printf("c is a consonant %c\n",c);
		
}
