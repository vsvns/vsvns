#include<stdio.h>
main()
{
	int i=0,n,k;
	printf("enter the n value\n");
	scanf("%d",&n);
	while(i<=n)
	{
	k=(i%2==0);
	printf("%d\n",k);
	i++;
    }
}

