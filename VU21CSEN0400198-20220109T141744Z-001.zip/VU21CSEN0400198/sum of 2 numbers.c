#include<stdio.h>
 main()
{
	float a,b,c,sum;
	printf("enter the a value");
	scanf("%f\n",&a);
	printf("enter the b value");
	scanf("%f\n",&b);
	c=a+b;
	printf("sum of 2 numbers %f\n",c);
}
